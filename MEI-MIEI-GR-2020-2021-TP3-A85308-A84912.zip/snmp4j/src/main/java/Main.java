/**
 * Classe Main
 *
 * @author Filipe Miguel Teixeira Freitas Guimarães - A865308
 * @author Joana Isabel Afonso Gomes - A84912
 */
public class Main {

    public static void main(String[] args) {
        MainFX.main(args);
    }
}
